/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}", // ✅ Your src folder and all files inside
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
