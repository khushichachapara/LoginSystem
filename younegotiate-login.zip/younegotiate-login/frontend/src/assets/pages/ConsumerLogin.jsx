const ConsumerLogin = () => {
  return (
    <div>
      <h1>Consumer Login</h1>
      <p>This is the Consumer Login page.</p>
    </div>
  );
}
export default ConsumerLogin;