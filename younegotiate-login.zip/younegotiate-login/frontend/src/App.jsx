import { useState } from 'react'
import RoutesApp from "./Routes/RoutesApp";
import './index.css';



function App() {
  return (
    <div >
      {/* <Home/> */}
      
      <RoutesApp/>

    </div>
  );
}

export default App;


