import { useState } from 'react'
import RoutesApp from "./Routes/RoutesApp";


function App() {
  return (
    <div >
      {/* <Home/> */}
      {/* <CreditorDashbord /> */}
      <RoutesApp/>

    </div>
  );
}

export default App;


