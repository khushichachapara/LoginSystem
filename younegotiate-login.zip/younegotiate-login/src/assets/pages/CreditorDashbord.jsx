function CreditorDashbord() {
  return (
    <div>
      <h1>Creditor Dashboard</h1>
      <p>Welcome to the Creditor Dashboard!</p>
    </div>
    
  );
}
export default CreditorDashbord;
