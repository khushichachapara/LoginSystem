import React from "react";

const Home = () => {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      {/* Navbar */}
      <nav className="flex items-center justify-between px-6 py-4 bg-white shadow">
        <h1 className="text-2xl font-bold text-blue-600">YouNegotiate</h1>
        <div className="space-x-4">
          <a href="#" className="text-gray-700 hover:text-blue-600">Home</a>
          <a href="#" className="text-gray-700 hover:text-blue-600">About</a>
          <a href="#" className="text-gray-700 hover:text-blue-600">Contact</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="flex flex-col-reverse md:flex-row items-center justify-between p-10 bg-gradient-to-r from-blue-50 to-white">
        <div className="max-w-xl space-y-4">
          <h2 className="text-4xl font-bold text-blue-700">Negotiate Your Debt, The Smart Way</h2>
          <p className="text-gray-600">Helping creditors and consumers find fair, fast, and secure resolutions.</p>
          <button className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition">Get Started</button>
        </div>
        <img src="/assets/images/hero.png" alt="Hero" className="w-96" />
      </section>

      {/* Steps or Features */}
      <section className="py-12 bg-white">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8 text-center">
          <div>
            <h3 className="text-xl font-semibold text-blue-600">Step 1</h3>
            <p className="text-gray-600">Creditor creates an account and sends invite.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-blue-600">Step 2</h3>
            <p className="text-gray-600">Consumer logs in securely using their details.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-blue-600">Step 3</h3>
            <p className="text-gray-600">Both parties negotiate terms and reach agreement.</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="text-center py-10 bg-blue-600 text-white">
        <h2 className="text-3xl font-bold mb-4">Start Negotiating Now</h2>
        <button className="bg-white text-blue-600 font-semibold px-6 py-2 rounded-full hover:bg-gray-100">Sign Up</button>
      </section>

      {/* Footer */}
      <footer className="text-center p-6 text-sm bg-gray-100">
        © 2025 YouNegotiate. All rights reserved.
      </footer>
    </div>
  );
};

export default Home;

